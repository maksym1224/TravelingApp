<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['appID']    = '1660831194160373';
$config['appSecret']    = '7a2c2ba7ec16c0f7c757375220d356c2';