var less = {
    logLevel: 4,
    errorReporting: "console",
    globalVars: {
        "@global-var": "red"
    }
};
